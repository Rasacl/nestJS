uinv.iconUserConfig = {
  "name": "区域面-矩阵革命",
  "version": "2.0",
  "config": {
    "totalSize": 1,
    "size": 1,
    "场景类型": "地图",
    "items": [
      {
        "type": "Polygon/Color",
        "tag": "默认面02",
        "name": "默认面02",
        "config": {
          "color": "#185141",
          "opacity": 70,
          "inheritStyle": false,
          "inheritVisible": true,
          "height": 2000,
          "offsetHeight": 0,
          "userData": {
            "SKIP_THEME": true
          },
        }
      },
      {
        "type": "Polygon/Image",
        "tag": "默认面01",
        "name": "默认面01",
        "config": {
          "imageDensity": 0.2,
          "image": './images/01.png',
          "opacity": 100,
          "inheritStyle": false,
          "inheritVisible": true,
          "height": 2000,
          "offsetHeight": 0,
          "userData": {
            "SKIP_THEME": true
          },
          "outlineWidth": 10,
          "outlineColor": "#00ffbc",
          "outlineOpacity": 1
        }
      },
    ]
  },
  "configUI": [
    {
      "caption": "3D设置",
      "content": "面标记在地图中支持geojson，园区中支持points",
      "type": "block",
      "des": "区块"
    },
    {
      "caption": "场景类型",
      "type": "valueDefault",
      "content": "面标记在地图、园区、不同层级下的厚度进行设置，不同层级下的默认大小是基准值，作为调整参数的参考",
      "des": "场景类型",
      "defaultValues": {
        "地图": {
          "items/0/config/height,items/1/config/height": 2000
        },
        "园区": {
          "items/0/config/height,items/1/config/height": 2
        },
        "室内": {
          "items/0/config/height,items/1/config/height": 2
        }

      },
      "block": {
        "name": "3D设置",
        "line": 1
      }
    },
    {
      "caption": "基本样式",
      "type": "block",
      "des": "区块"
    },
    {
      "caption": "面拔高",
      "type": "number",
      "block": {
        "name": "基本样式",
        "line": 1
      },
      "content": "面的厚度设置",
      "des": "items/0/config/height,items/1/config/height",
      "width": 200
    },

    {
      "caption": "面颜色",
      "type": "color",
      "des": "items/0/config/color",
      "block": {
        "name": "基本样式",
        "line": 2
      }
    },
    {
      "caption": "面透明度",
      "type": "slider",
      "content": "面的透明度固定或随机设置",
      "des": "items/0/config/opacity",
      "isNeedChange": true, //控制是否显示radio,默认为false
      "min": 0,
      "max": 100,
      "step": 1,
      "unit": "%",
      "block": {
        "name": "基本样式",
        "line": 3
      }
    },
    {
      "caption": "贴图重复度",
      "type": "number",
      "des": "items/1/config/imageDensity",
      "content": "贴图在区域面上的重复程度，数值越大间隔越小",
      "block": {
        "name": "基本样式",
        "line": 4
      }
    },
    {
      "caption": "离地高度",
      "type": "number",
      "des": "items/0/config/offsetHeight,items/1/config/offsetHeight",
      "content": "面与地面之间的距离",
      "block": {
        "name": "基本样式",
        "line": 5
      }
    },
    {
      "caption": "描边宽度",
      "type": "number",
      "des": "items/1/config/outlineWidth",
      "content": "园区和室内不支持自定义描边宽度",
      "block": {
        "name": "基本样式",
        "line": 6
      },
      "width": 200
    },
    {
      "caption": "描边颜色",
      "type": "color",
      "des": "items/1/config/outlineColor",
      "block": {
        "name": "基本样式",
        "line": 7
      }
    }
  ]
}
