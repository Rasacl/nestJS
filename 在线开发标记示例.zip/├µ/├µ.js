// 创建app
let app = new THING.App();
// 设置背景颜色
app.background = [0, 0, 0];
THING.Utils.dynamicLoad([
    "https://www.3dmmd.cn/static/attachment/js/objectdecorator.min.js",   // 引入标记库
    "https://www.thingjs.com/uearth/uearth.min.js",     // 引用地图组件脚本  
], function () {
    // 第一步：创建标记实例
    let atm = new Attachment();
    let mountObjs = null, // 标记挂载对象
        atmPath, // 标记路径 
        configUI, // 标记的可配置项 注configUI和configUIpro合并在此
        atmObj; // 创建的标记对象 

    app.create({
        type: 'Map',
        url: 'https://www.thingjs.com/citybuilder_console/mapProject/config/TVRRek5UYzRDaXR5QnVpbGRlckAyMDE5/true',
        complete: function (event) {
            mountObjs = createPolygonDataObjs();

            // 创建图层按钮
            new THING.widget.Button('创建', function () {
                create();
            });
            new THING.widget.Button('配置', function () {
                refresh();
            });
            new THING.widget.Button('销毁', function () {
                atm.destroy(mountObjs, atmPath);
            });
        }
    });

    async function create() {
        // 第二步：收集资源，标记的资源包
        atmPath = '/uploads/wechat/oLX7p03AbaqXhBt8aiznssewknMk/file/面/区域面';
        // 第三步：创建标记 
        // 给父对象创建标记
        let results = atm.create(mountObjs, atmPath);
        // configUI 用于配置标记大小、颜色、数据获取地址
        configUI = await atm.getConfigUI(atmPath);
        console.log('配置项', configUI);

        // 得到创建的标记对象
        atmObj = await results.then(resp => { return resp.objects });
        console.log('标记对象', atmObj);
    }


    function refresh() {
        // 第一步：拿到想要改动的配置项路径且赋值
        //拿到想改动的配置项configUI 把控制台中configUI的des属性放入src，把要修改的值放入value即可
        let refreshConfigUI = [
            {
                "src": "items/1/config/outlineColor",
                "value": "#ff4400"
            },
            {
                "src": "items/0/config/opacity",
                "value": 10
            }
        ];
        // 第二步：刷新标记
        atm.refresh(mountObjs, atmPath, refreshConfigUI);
    }

    // 创建地图数据
    function createPolygonDataObjs() {
        let polygonObjs = [];
        $.ajax({
            type: "GET",
            url: "https://www.3dmmd.cn/static/attachment/attachment-resource/plogenData/subpolygon.geojson",
            dataType: "json",
            async: false,
            success: function (data) {
                let baseObj = app.create({
                    type: 'BaseObject',
                });
                baseObj.position = CMAP.Util.convertLonlatToWorld(data.features[0].geometry.coordinates[0][0][0]);
                baseObj.geojson = data;
                polygonObjs.push(baseObj);
            }
        });
        return polygonObjs;
    }
});
