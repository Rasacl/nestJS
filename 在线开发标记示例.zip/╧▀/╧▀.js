// 创建app
let app = new THING.App();
// 设置背景颜色
app.background = [0, 0, 0];
THING.Utils.dynamicLoad([
    "https://www.3dmmd.cn/static/attachment/js/objectdecorator.min.js",   // 引入标记库
    "https://www.thingjs.com/uearth/uearth.min.js",     // 引用地图组件脚本  
], function () {
    // 第一步：创建标记实例
    let atm = new Attachment();
    let mountObjs = null, // 标记挂载对象
        atmPath, // 标记路径 
        configUI, // 标记的可配置项 注configUI和configUIpro合并在此
        atmObj; // 创建的标记对象 

    app.create({
        type: 'Map',
        url: 'https://www.thingjs.com/citybuilder_console/mapProject/config/TVRRek5UYzRDaXR5QnVpbGRlckAyMDE5/true',
        complete: function (event) {
            mountObjs = createLineDataObjs();

            // 创建图层按钮
            new THING.widget.Button('创建', function () {
                create();
            });
            new THING.widget.Button('配置', function () {
                refresh();
            });
            new THING.widget.Button('销毁', function () {
                atm.destroy(mountObjs, atmPath);
            });
        }
    });

    async function create() {
        // 第二步：收集资源，标记的资源包
        atmPath = '/uploads/wechat/oLX7p03AbaqXhBt8aiznssewknMk/file/线/起止线';
        // 第三步：创建标记 
        // 给父对象创建标记
        let results = atm.create(mountObjs, atmPath);
        // configUI 用于配置标记大小、颜色、数据获取地址
        configUI = await atm.getConfigUI(atmPath);
        console.log('配置项', configUI);

        // 得到创建的标记对象
        atmObj = await results.then(resp => { return resp.objects });
        console.log('标记对象', atmObj);
    }


    function refresh() {
        // 第一步：拿到想要改动的配置项路径且赋值
        //拿到想改动的配置项configUI 把控制台中configUI的des属性放入src，把要修改的值放入value即可
        let refreshConfigUI = [
            {
                "src": "items/0/config/uvRatio/0",
                "value": 5
            },
            {
                "src": "items/0/config/width",
                "value": 100
            },
            {
                "src": "items/0/config/color",
                "value": "#ff0000"
            }
        ];
        // 第二步：刷新标记
        atm.refresh(mountObjs, atmPath, refreshConfigUI);
    }

    // 创建地图线数据对象
    function createLineDataObjs() {
        let lineDataObjs = [];
        let flyLineData = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "properties": {},
                    "geometry": {
                        "type": "Point",
                        "coordinates": [
                            [
                                108.984375,
                                34.45221847282654
                            ],
                            [
                                126.5625,
                                45.9511496866914
                            ]
                        ]
                    }
                },

            ]
        };
        for (let i = 0; i < flyLineData.features.length; i += 1) {
            let baseObj = app.create({
                type: 'BaseObject',
            });
            let coors = flyLineData.features[i].geometry.coordinates;
            baseObj.position = CMAP.Util.convertLonlatToWorld(flyLineData.features[i].geometry.coordinates[0]);
            baseObj.startLonlat = coors[0];
            baseObj.endLonlat = coors[1];
            baseObj.userData._TYPE_ = 'GEOODLINE';
            baseObj.name = flyLineData.features[i].properties['终点']
            lineDataObjs.push(baseObj);
        }
        return lineDataObjs;
    }
});
