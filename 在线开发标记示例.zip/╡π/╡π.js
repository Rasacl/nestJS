THING.Utils.dynamicLoad([
    // 引入标记库
    "https://www.3dmmd.cn/static/attachment/js/objectdecorator.min.js",
], function () {
    // 第一步：创建标记实例
    let atm = new Attachment();
    let mountObjs = null, // 标记挂载对象
        atmPath, // 标记路径 
        configUI, // 标记的可配置项 注configUI和configUIpro合并在此
        atmObj; // 创建的标记对象 

    // 加载ThingJS场景
    var app = new THING.App({
        url: 'http://www.thingjs.com/static/models/factory',
    });

    app.on('load', function () {
        new THING.widget.Button("创建标记", function () {
            if(mountObjs){
            atm.destroy(mountObjs, atmPath);
            };
            mountObjs = app.query(/car/).objects[0];
            create();
        });
        new THING.widget.Button("配置标记", function () {
          mountObjs = app.query(/car/).objects[0];
            refresh();
        });

        new THING.widget.Button("批量创建标记", function () {
             if(mountObjs){
               atm.destroy(mountObjs, atmPath);
              }
             mountObjs = app.query(/car/).objects;
             create();
        });
        new THING.widget.Button("批量配置标记", function () {
              mountObjs = app.query(/car/).objects;
              refresh();
        });
        new THING.widget.Button("销毁标记", function () {
            atm.destroy(mountObjs, atmPath);
        });
    })

    async function create() {
        // 第二步：收集资源，标记的资源包
        atmPath = '/uploads/wechat/oLX7p03AbaqXhBt8aiznssewknMk/file/数据面板/三行数据状态';

        // 第三步：创建标记 
        // 给父对象创建标记
        let results = atm.create(mountObjs, atmPath);
        // configUI 用于配置标记大小、颜色、数据获取地址
        configUI = await atm.getConfigUI(atmPath);
        console.log('配置项', configUI);

        // 得到创建的标记对象
        // atmObj.refresh() 刷新标记数据
        atmObj = await results.then(resp => { return resp.objects });
        console.log('标记对象', atmObj);
    }

    function refresh() {
        // 第一步：拿到想要改动的配置项路径且赋值
        //拿到想改动的配置项configUI 把控制台中configUI的des属性放入src，把要修改的值放入value即可
        let refreshConfigUI = [
            {
                "src": "scaleFactor",
                "value": 20
            }, {
                "src": 'keepSize',
                'value': false
            }
        ];
        // 第二步：刷新标记
        atm.refresh(mountObjs, atmPath, refreshConfigUI);
    }
});
